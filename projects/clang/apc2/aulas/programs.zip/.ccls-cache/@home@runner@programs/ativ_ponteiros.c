#include <stdio.h>

// Colocar aqui os códigos caso seja necessário.
int main(void) { }